// FULL FLUTTER PROJECT WITH:
// 1. Student list (multiple cards)
// 2. Detail page
// 3. Responsive layout
// 4. Bottom navigation bar
// 5. Dark mode toggle
// 6. Page transition animation
// 7. Dummy student model

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool darkMode = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: darkMode ? Brightness.dark : Brightness.light,
        primarySwatch: Colors.blue,
      ),
      home: MainNavigation(
        toggleDark: () {
          setState(() => darkMode = !darkMode);
        },
      ),
    );
  }
}

// ===================== MODEL =====================
class Student {
  final String name;
  final String nim;
  final String major;
  final String photo;

  Student({required this.name, required this.nim, required this.major, required this.photo});
}

List<Student> studentList = [
  Student(
    name: "Prastya Firmansyah",
    nim: "22190001",
    major: "Informatika",
    photo: "https://i.pravatar.cc/150?img=1",
  ),
  Student(
    name: "Rama Aditya",
    nim: "22190002",
    major: "Sistem Informasi",
    photo: "https://i.pravatar.cc/150?img=2",
  ),
  Student(
    name: "Putri Annisa",
    nim: "22190003",
    major: "Teknik Komputer",
    photo: "https://i.pravatar.cc/150?img=3",
  ),
];

// ===================== MAIN NAVIGATION =====================
class MainNavigation extends StatefulWidget {
  final VoidCallback toggleDark;
  const MainNavigation({super.key, required this.toggleDark});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const StudentListScreen(),
      SettingsScreen(toggleDark: widget.toggleDark),
    ];

    return Scaffold(
      body: pages[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: (i) => setState(() => currentIndex = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.people), label: "Mahasiswa"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Pengaturan"),
        ],
      ),
    );
  }
}

// ===================== STUDENT LIST =====================
class StudentListScreen extends StatelessWidget {
  const StudentListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Daftar Mahasiswa")),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: studentList.length,
        itemBuilder: (context, index) {
          final st = studentList[index];
          return StudentCard(student: st);
        },
      ),
    );
  }
}

// ===================== STUDENT CARD =====================
class StudentCard extends StatelessWidget {
  final Student student;
  const StudentCard({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Colors.blue.shade50,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            PageRouteBuilder(
              transitionDuration: const Duration(milliseconds: 400),
              pageBuilder: (_, __, ___) => StudentDetailScreen(student: student),
              transitionsBuilder: (_, animation, __, child) {
                return FadeTransition(opacity: animation, child: child);
              },
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(radius: 35, backgroundImage: NetworkImage(student.photo)),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      student.name,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text("NIM : ${student.nim}"),
                    Text("Program Studi : ${student.major}"),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: Colors.blue.shade400,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text("Lihat Detail", style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

// ===================== DETAIL PAGE =====================
class StudentDetailScreen extends StatelessWidget {
  final Student student;
  const StudentDetailScreen({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Detail Mahasiswa")),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(radius: 60, backgroundImage: NetworkImage(student.photo)),
              const SizedBox(height: 20),
              Text(student.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text("NIM : ${student.nim}", style: const TextStyle(fontSize: 18)),
              Text("Program Studi : ${student.major}", style: const TextStyle(fontSize: 18)),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Kembali"),
              )
            ],
          ),
        ),
      ),
    );
  }
}

// ===================== SETTINGS SCREEN =====================
class SettingsScreen extends StatelessWidget {
  final VoidCallback toggleDark;
  const SettingsScreen({super.key, required this.toggleDark});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Pengaturan")),
      body: Center(
        child: ElevatedButton(
          onPressed: toggleDark,
          child: const Text("Toggle Dark Mode"),
        ),
      ),
    );
  }
}
