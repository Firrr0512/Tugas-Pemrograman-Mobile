import 'package:flutter/material.dart';

void main() => runApp(CoffeeApp());

class CoffeeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kedai Kopi Digital',
      theme: ThemeData(
        colorSchemeSeed: Colors.brown,
        useMaterial3: true,
      ),
      home: CoffeeHomePage(),
    );
  }
}

class CoffeeHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Kedai Kopi Digital ☕"),
        centerTitle: true,
        backgroundColor: Colors.brown[600],
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Banner
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.network(
                  "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=1200",
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 16),

              // Title + subtitle
              Text(
                "Selamat Datang di Kedai Kopi Digital",
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: Colors.brown[800],
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 6),
              Text(
                "Nikmati berbagai racikan kopi pilihan dengan suasana damai.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 16),

              // Row: 3 kategori menu
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _menuCard(Icons.coffee, "Kopi Hitam"),
                  _menuCard(Icons.emoji_food_beverage, "Cappuccino"),
                  _menuCard(Icons.local_cafe, "Latte"),
                ],
              ),

              const SizedBox(height: 20),

              // Row: rating dan waktu buka
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: const [
                      Icon(Icons.star, color: Colors.amber),
                      SizedBox(width: 6),
                      Text("4.9 dari 5"),
                    ],
                  ),
                  Row(
                    children: const [
                      Icon(Icons.schedule, color: Colors.brown),
                      SizedBox(width: 6),
                      Text("Buka: 08.00 - 22.00"),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // Tombol aksi
              Center(
                child: ElevatedButton.icon(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.brown[700],
                    foregroundColor: Colors.white,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  icon: const Icon(Icons.shopping_bag),
                  label: const Text(
                    "Pesan Sekarang",
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // Footer
              Center(
                child: Column(
                  children: [
                    Text(
                      "© 2025 Kedai Kopi Digital",
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.favorite, size: 14, color: Colors.red),
                        SizedBox(width: 6),
                        Text("Dibuat dengan cinta & kafein"),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _menuCard(IconData icon, String label) {
    return Expanded(
      child: Column(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: Colors.brown[100],
            child: Icon(icon, color: Colors.brown[700], size: 30),
          ),
          const SizedBox(height: 8),
          Text(label,
              style: const TextStyle(
                  fontWeight: FontWeight.w600, color: Colors.brown)),
        ],
      ),
    );
  }
}
